<?php
  include 'admin/php_files/database.php';

  // $hostname = "http://localhost/shoppingproject-yb";
  $hostname = "http://laalmon.com";
    
?>